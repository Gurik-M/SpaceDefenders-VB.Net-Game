﻿Public Interface IKeyboardListener
    Sub KeyDown(keyCode As Keys)
    Sub KeyUp(keyCode As Keys)
End Interface
