﻿Public Class frmWelcome
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        frmGame.Show()
        Me.Hide()
    End Sub

    Private Sub btnJump_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub
End Class